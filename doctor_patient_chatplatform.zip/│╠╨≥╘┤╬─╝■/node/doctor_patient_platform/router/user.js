const express = require('express')
const router = express.Router()

//导入用户路由处理函数对应的模块
const user_handler = require('../router_handler/user')

//注册新用户
router.post('/register', user_handler.register)

//登录
router.post('/login',user_handler.login)

router.post('/test',(req,res) => {res.send('ok')})

module.exports = router