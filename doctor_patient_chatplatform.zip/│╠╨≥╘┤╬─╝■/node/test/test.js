const express = require('express')

const app = express()

app.get('/',(req,res)=>{
    res.send('hello a')
})

app.post('/',(req,res)=>{
    res.send('hello b')
})

app.listen(80,() =>{
    console.log('you have log in ')
})
