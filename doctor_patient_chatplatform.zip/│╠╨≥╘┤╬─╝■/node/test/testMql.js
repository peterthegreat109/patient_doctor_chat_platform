const mysql = require('mysql')

const db = mysql.createPool({
    host: '127.0.0.1',
    user: 'root',
    password: 'ZXH123++',
    database: 'user'
})

const sqlStr = 'SELECT * FROM patient_info'

db.query(sqlStr,(err, results) => {
    if(err) return console.log(err.message)
    console.log(results)
})