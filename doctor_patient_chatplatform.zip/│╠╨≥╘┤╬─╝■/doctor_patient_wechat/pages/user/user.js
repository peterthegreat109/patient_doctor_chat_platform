// pages/user/user.js
const app = getApp()
var count = 0

Page({
  data: {
    
  },
  onShow() {
    this.setData({
      userInfo: app.globalData.userInfo,
      avatarUrl : app.globalData.userInfo.avatarUrl
   })
  },


  getUserAccount(e) {
    this.setData({
      account_id : e.detail.value
    })
  },

  getUserPassword(e) {
    this.setData({
      ps : e.detail.value
    })
  },

  login() {
    const that = this;
    console.log(this);
    wx.request({
      url: 'http://127.0.0.1/api/login', 
      method: 'post',
      data: {
        username: that.data.account_id,
        password: that.data.ps
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res){
          console.log(res)
          console.log(that.data.account_id)
          if(res.data.status === 1){
            wx.showToast({
              icon : 'error',
              title: '账号密码有误',
            })
            return;
          }else{
            wx.showToast({
              title: '登陆成功！',
            })
          }
          // 将用户名和密码保存到全局变量 app.globalData中
          this.id = 1;
        }
      })
    
  },

  refresh(){
    app.globalData.userInfo = null;
    this.onLoad();
  },
  /**
   * 生命周期函数--监听页面显示
   */

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
})
