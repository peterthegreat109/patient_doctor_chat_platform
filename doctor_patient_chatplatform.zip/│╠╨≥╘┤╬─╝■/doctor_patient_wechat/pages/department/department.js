// pages/department/department.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentIndex: 0,
    rightId: 'right0',
    leftNum:0,

    left:[{
      id: 0,
      text: '内科',
      subArr: [{
          subId: 0,
          text: '神经内科',
        },{
          subId: 1,
          text: '消化内科'
        },{
          subId: 2,
          text: '呼吸内科'
        },{
          subId: 3,
          text: '心血管内科'
        },{
          subId: 4,
          text: '肾内科'
        }]
      },{
      id: 1,
      text: '外科',
      subArr: [{
          subId: 0,
          text: '骨科',
        },{
          subId: 1,
          text: '普外科'
        },{
          subId: 2,
          text: '胸外科'
        },{
          isubId: 3,
          text: '泌尿外科'
        }]
      },{
      id:2,
      text:'中医科', 
      subArr: [{subId:0,text:'中医科'}]
      },{
      id:3,
      text:'妇产科', 
      subArr: [{subId:0,text:'妇产科'}]
      }]

    
  },

/* 左侧栏科室更换*/
depChange(e){
  const {index} = e.currentTarget.dataset;
  this.setData({
    currentIndex:index,
    rightId: 'right'+index
  })
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})